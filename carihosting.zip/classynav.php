<ul id="nav">
	<li <?=($page=='index'?'class="active"':'')?> ><a href="./index.php">Home</a></li>
	<li <?=($page=='hosting'?'class="active"':'')?> ><a href="./hosting.php">Hosting</a></li>
	<!--
	<li><a href="#">Pages</a>
		<ul class="dropdown">
			<li><a href="./index.html">- Home</a></li>
			<li><a href="./hosting.html">- Hosting</a></li>
			<li><a href="./about.html">- About</a></li>
			<li><a href="./blog.html">- Blog</a></li>
			<li><a href="./single-blog.html">- Blog Details</a></li>
			<li><a href="./404.html">- 404</a></li>
			<li><a href="./coming-soon.html">- Coming Soon</a></li>
			<li><a href="#">- Dropdown</a>
				<ul class="dropdown">
					<li><a href="#">- Dropdown Item</a></li>
					<li><a href="#">- Dropdown Item</a></li>
					<li><a href="#">- Dropdown Item</a></li>
					<li><a href="#">- Dropdown Item</a></li>
				</ul>
			</li>
		</ul>
	</li>
	-->
	<li <?=($page=='about'?'class="active"':'')?> ><a href="./about.php">About</a></li>
	<!--
	<li><a href="./blog.html">Blog</a></li>
	<li><a href="#">Contact</a></li>
	-->
</ul>

<!-- Live Chat -->
<div class="live-chat-btn ml-5 mt-4 mt-lg-0 ml-md-4">
    <a href="livechat.php" class="btn hami-btn live--chat--btn"><i class="fa fa-comments" aria-hidden="true"></i> Live Chat</a>
</div>
