<div class="col-6">
	<div class="top-header-content">
		<a href="#"><i class="fa fa-phone" aria-hidden="true"></i> <span>Call Us: 0822-9721-7939</span></a>
		<a href="#"><i class="fa fa-envelope" aria-hidden="true"></i> <span>Email: carihosting@gmail.com</span></a>
	</div>
</div>

<div class="col-6">
	<div class="top-header-content">
		<!-- Login -->
		<!--
		<a href="#"><i class="fa fa-lock" aria-hidden="true"></i> <span>Login / Register</span></a>
		-->
		<!-- Language -->
		<!--
		<div class="dropdown">
			<a class="btn pr-0 dropdown-toggle" href="#" role="button" id="langdropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="img/core-img/eng.png" alt=""> English</a>
			<div class="dropdown-menu dropdown-menu-right" aria-labelledby="langdropdown">
				<a class="dropdown-item" href="#">- Indonesia</a>
			</div>
		</div>
		-->
	</div>
</div>
