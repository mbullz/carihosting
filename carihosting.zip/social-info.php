<!-- Social Info -->
<div class="social-info">
    <a href="http://www.facebook.com" class="facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a>
    <a href="http://www.twitter.com" class="twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a>
    <a href="http://www.google.com" class="google-plus"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
    <a href="http://www.instagram.com" class="instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a>
    <a href="http://www.youtube.com" class="youtube"><i class="fa fa-youtube" aria-hidden="true"></i></a>
</div>